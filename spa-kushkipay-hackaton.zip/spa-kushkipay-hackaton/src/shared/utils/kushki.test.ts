import { KushkiJs } from "./kushki";
import { get } from "lodash";
describe("kuski test", () => {
  beforeEach(() => {
    new KushkiJs("123444");
  });
  it("", () => {
    expect(get(KushkiJs.getKushkiJs(), "_merchantId")).toEqual("123444");
  });
});
