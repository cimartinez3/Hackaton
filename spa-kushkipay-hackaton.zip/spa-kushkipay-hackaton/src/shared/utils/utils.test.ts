import { PaymentMethodsEnum } from "../infrastructure/PaymentMethodEnum";
import { PaymentTypeEnum } from "../infrastructure/PaymentTypeEnum";
import { KushkiJs } from "./kushki";
import {
  buildSmartlinkV1,
  orderPaymentMethods,
  validateSmartlink,
  verifySmartlinkType,
} from "./utils";
import { GeneralConfig, SmartLink } from "../../../types/smart_link_V2";
import { RouteEnum } from "../infrastructure/RouteEnum";
import { FormResponse } from "../../../types/form_response";
import * as H from "history";

// @ts-ignore
const mockHistory: H.History = { push: jest.fn() };

jest.mock("react-router-dom", () => ({
  useHistory: () => mockHistory,
}));

describe("Utils test", () => {
  describe("validateSmartlink", () => {
    const homePath: string = "";
    let windowCopy: Window;

    beforeAll(() => {
      windowCopy = global.window;
    });

    beforeEach(() => {
      Object.defineProperty(global, "window", {
        value: {
          location: {
            pathname: homePath,
            search: "search",
          },
        },
      });
    });

    afterAll(() => {
      Object.defineProperty(global, "window", { value: windowCopy });
    });

    it("must not redirect, when smartlink is valid", () => {
      validateSmartlink({ enabled: true } as GeneralConfig, mockHistory);

      expect(window.location.pathname).toEqual(homePath);
    });

    it("must redirect to outstock when executionLimit is less than executionCount", () => {
      validateSmartlink(
        {
          executionCount: 1,
          executionLimit: 1,
        } as GeneralConfig,
        mockHistory
      );
      expect(mockHistory.push).toHaveBeenCalledWith(RouteEnum.OUTSTOCK);
    });

    it("must redirect to expirad, when expirationDate is not valid", () => {
      validateSmartlink(
        {
          expirationDate: "1",
        } as GeneralConfig,
        mockHistory
      );

      expect(mockHistory.push).toHaveBeenCalledWith(RouteEnum.EXPIRED_LINK);
    });

    it("must redirect to not avail, when smartlink not enabled", () => {
      validateSmartlink(
        {
          enabled: false,
        } as GeneralConfig,
        mockHistory
      );

      expect(mockHistory.push).toHaveBeenCalledWith(RouteEnum.NOT_AVAIL);
    });
  });

  describe("Kushjs singleton", () => {
    it("must have requestToken property", () => {
      const kushkijs: KushkiJs = new KushkiJs("12341234");

      expect(kushkijs).toBeTruthy();
    });
  });

  describe("SmartlinkV1", () => {
    let smartlink: FormResponse;

    beforeEach(() => {
      smartlink = {
        amount: {
          currency: "USD",
        },
        form: [{}],
        logo: "somelogo",
        paymentMethod: "card-async",
        subscriptionTotalAmount: 200,
        totalAmount: 100,
      };
    });

    it("must build old smartlink", () => {
      const smartlinkV2: SmartLink = buildSmartlinkV1("", smartlink);

      expect(smartlinkV2).toBeTruthy();
    });

    it("must verifySmartlinkType paymentMethod as array", () => {
      smartlink.paymentMethod = [PaymentMethodsEnum.SUBSCRIPTION];

      expect(verifySmartlinkType(smartlink)).toEqual(
        PaymentTypeEnum.SUBSCRIPTION
      );
    });

    it("must return MIXED paymentMethod as array", () => {
      smartlink.paymentMethod = [
        PaymentMethodsEnum.SUBSCRIPTION,
        PaymentMethodsEnum.TRANSFER,
      ];

      expect(verifySmartlinkType(smartlink)).toEqual(PaymentTypeEnum.MIXED);
    });
  });

  describe("Functions", () => {
    let paymentMethods: string[];

    it("Test orderPaymentMethods", () => {
      paymentMethods = [
        "cash",
        "transfer",
        "credit-card",
        "card-async",
        "transfer-subscription",
      ];
      const orderedMethods = [
        "credit-card",
        "transfer",
        "transfer-subscription",
        "card-async",
        "cash",
      ];

      expect(orderPaymentMethods(paymentMethods)).toEqual(orderedMethods);
    });
  });
});
