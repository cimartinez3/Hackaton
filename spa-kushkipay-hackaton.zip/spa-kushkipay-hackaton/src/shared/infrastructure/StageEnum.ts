/**
 * StageEnum
 */
export enum StageEnum {
  PRODUCTION = "primary",
  UAT = "uat",
  QA = "qa",
  CI = "ci",
}
