export enum EndpointEnum {
  SMARTLINK_V2 = "smartlink/v2/smart-link",
}
