export enum TransferBrandsEnum {
  PSE = "pse",
  STP = "stp",
  ACCENDO = "accendo",
}
