export enum CountryEnum {
  EC = "Ecuador",
  CO = "Colombia",
  PE = "Peru",
  CL = "Chile",
  MX = "Mexico",
}
