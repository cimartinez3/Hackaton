export enum PaymentTypeEnum {
  SUBSCRIPTION = "subscription",
  MIXED = "mixed",
  UNIQUE = "unique",
}
