import { ReactComponent as visa } from "../../assets/logos/visa.svg";
import { ReactComponent as mastercard } from "../../assets/logos/Mastercard.svg";
import { ReactComponent as amex } from "../../assets/logos/amex.svg";
import { ReactComponent as diners } from "../../assets/logos/Diners.svg";
import { ReactComponent as discover } from "../../assets/logos/Discover.svg";
import { ReactComponent as CashImg } from "../../assets/images/paymentMethods/cash.svg";
import { ReactComponent as TransferImg } from "../../assets/images/paymentMethods/transfer.svg";
import { FC } from "react";
import { CardsEnum } from "./CardsEnum";

export const BRANDS_IMGS: Record<CardsEnum, FC> = {
  [CardsEnum.visa]: visa,
  [CardsEnum.amex]: amex,
  [CardsEnum.diners]: diners,
  [CardsEnum.discover]: discover,
  [CardsEnum.mastercard]: mastercard,
  [CardsEnum.transfer]: TransferImg,
  [CardsEnum.cash]: CashImg,
};
