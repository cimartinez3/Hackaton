/* istanbul ignore file */
/**
 * TextOtpCountry Enumeration
 */
enum TextOtpCountryEnum {
  CO = "KUSHKI VERIFICACION",
  EC = "HELP_KUSHKI VERIFICACIÓN",
  MX = "BP*KS*VERIFICACION",
  PE = "KSK*VERIFICACION PE",
  CL = "VERIFICACION KS",
}

export enum CountryEnum {
  EC = "Ecuador",
  CO = "Colombia",
  PE = "Peru",
  CL = "Chile",
  MX = "Mexico",
}

export const getTextByCountry = (country: string): string => {
  switch (country) {
    case CountryEnum.CO:
      return TextOtpCountryEnum.CO;
    case CountryEnum.EC:
      return TextOtpCountryEnum.EC;
    case CountryEnum.MX:
      return TextOtpCountryEnum.MX;
    case CountryEnum.PE:
      return TextOtpCountryEnum.PE;
    case CountryEnum.CL:
      return TextOtpCountryEnum.CL;
    default:
      return TextOtpCountryEnum.EC;
  }
};
