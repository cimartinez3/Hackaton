export enum TransferProcessorsEnum {
  PSE = "Pse Processor",
  ETPay = "ETPay Processor",
  ETPayPlus = "ETPayPlus Processor",
  ACCENDO = "Accendo Processor",
  STP = "STP Processor",
}
