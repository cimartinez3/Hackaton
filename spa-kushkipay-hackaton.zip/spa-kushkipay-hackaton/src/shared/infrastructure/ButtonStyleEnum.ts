export enum ButtonStyleEnum {
  ROUND = "round",
  SEMI = "semi",
  SQUARE = "square",
}
