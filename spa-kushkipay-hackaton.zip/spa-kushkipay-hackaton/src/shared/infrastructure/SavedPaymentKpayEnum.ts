export enum SavedPaymentKpayEnum {
  CARD = "card",
  CASH = "cash",
  TRANSFER = "transfer",
}
