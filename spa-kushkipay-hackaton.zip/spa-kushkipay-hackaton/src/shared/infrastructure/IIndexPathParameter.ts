export interface IIndexPathParameter {
  merchantName: string;
  smartlinkId: string;
}
