export const IdentificationNumberEnum: Record<
  string,
  { value: string; label: string }[]
> = {
  Brazil: [
    { label: "CPF", value: "CPF" },
    { label: "CNPJ", value: "CNPJ" },
    { label: "RG", value: "RG" },
    { label: "DNI", value: "DNI" },
    { label: "CI", value: "CI" },
    { label: "CP", value: "CP" },
    { label: "RNE", value: "RNE" },
  ],
  Chile: [
    { label: "CC", value: "CC" },
    { label: "NIT", value: "NIT" },
    { label: "RUT", value: "RUT" },
    { label: "TI", value: "TI" },
    { label: "PP", value: "PP" },
    { label: "CE", value: "CE" },
  ],
  Colombia: [
    { label: "CC", value: "CC" },
    { label: "NIT", value: "NIT" },
    { label: "CE", value: "CE" },
    { label: "TI", value: "TI" },
    { label: "PAS", value: "PAS" },
  ],
  Ecuador: [
    { label: "CI", value: "CI" },
    { label: "PAS", value: "PAS" },
    { label: "RUC", value: "RUC" },
  ],
  Mexico: [
    { label: "PP", value: "PP" },
    { label: "CURP", value: "CURP" },
    { label: "RFC", value: "RFC" },
  ],
  Peru: [
    { label: "DNI", value: "DNI" },
    { label: "CE", value: "CE" },
    { label: "PAS", value: "PAS" },
  ],
};
