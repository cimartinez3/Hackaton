export enum CallbackStatusEnum {
  APPROVED_TRANSACTION = "approvedTransaction",
  DECLINED_TRANSACTION = "declinedTransaction",
}
