export enum CardBrandsEnum {
  VISA = "visa",
  MASTERCARD = "mastercard",
  AMEX = "amex",
  DINERS = "diners",
}
