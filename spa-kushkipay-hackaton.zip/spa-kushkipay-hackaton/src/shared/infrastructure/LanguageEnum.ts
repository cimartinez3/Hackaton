export enum LanguageEnum {
  SPANISH = "es",
  ENGLISH = "en",
  PORTUGUESE = "br",
}
