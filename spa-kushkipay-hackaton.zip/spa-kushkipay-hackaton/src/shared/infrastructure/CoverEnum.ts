export enum CoverEnum {
  LEFT = "left",
  CENTER = "center",
  RIGHT = "right",
}
