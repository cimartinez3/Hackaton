export enum ResumeTypeEnum {
  SUCCESS = "SUCCESS",
  FAILED = "FAILED",
}
