import { Amount, CurrencyEnum } from "../../../types/smart_link_V2";

export interface IAmount {
  smartLinkAmount: Amount;
  currency: CurrencyEnum;
  subTotal: number;
  taxes: number;
  total: number;
}
