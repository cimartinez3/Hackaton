export enum StyleOrientationEnum {
  VERTICAL = "VERTICAL",
  HORIZONTAL = "HORIZONTAL",
}
