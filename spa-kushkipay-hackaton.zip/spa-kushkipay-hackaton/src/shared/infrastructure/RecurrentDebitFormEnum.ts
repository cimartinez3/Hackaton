export enum RecurrentDebitFormEnum {
  NAME = "name",
  DOCUMENT_TYPE = "documentType",
  IDENTIFICATION_NUMBER = "identificationNumber",
  BANK_ID = "bankId",
  ACCOUNT_TYPE = "accountType",
  ACCOUNT_NUMBER = "accountNumber",
  PHONE_NUMBER = "phoneNumber",
  EMAIL = "email",
}
