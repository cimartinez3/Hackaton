export interface CardIInterface {
  numberCard: string;
  nameCustomer: string;
  email: string;
  date: string;
  cvv: string;
}

export enum ScreenCard {
  NONE = "NONE",
  CAJITA = "CAJITA",
  CARDS = "CARDS",
  SUCCESSFULL = " SUCCESSFULL",
}

export enum EntityNameCard {
  VISA = "VISA",
  MASTERCARD = "MASTERCARD",
}

export interface CardCustomer {
  type: EntityNameCard;
  numberCard: string;
  nameCustomer: string;
  cardId: string;
}

export interface CardCustomers {
  data: CardCustomer[];
}
