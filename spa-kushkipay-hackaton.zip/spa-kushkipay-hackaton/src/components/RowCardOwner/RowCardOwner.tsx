import React, { FC } from "react";
import { Box, Card, IconButton, Typography } from "@mui/material";
import {
  CardCustomer,
  EntityNameCard,
  ScreenCard,
} from "../../shared/interfaces/CardI.interface";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import { rowCardStyles as styles } from "./RowCard.styles";
import { ModalOTP } from "../Modal/Modal";

export const RowCardOwner: FC<CardCustomer> = ({
  type,
  numberCard,
  nameCustomer,
  cardId,
}: CardCustomer) => {
  const [open, setOpen] = React.useState(false);

  const handleOpen = (open: boolean) => {
    setOpen(open);
  };

  return (
    <>
      <Card variant="outlined" sx={styles.mainCard}>
        <Box sx={styles.firstBox}>
          <img
            src={
              type === EntityNameCard.MASTERCARD
                ? "https://logodownload.org/wp-content/uploads/2014/07/mastercard-logo-7.png"
                : "https://logodownload.org/wp-content/uploads/2016/10/visa-logo-2.png"
            }
            alt="React Image"
            height="60px"
            width="80px"
          />
        </Box>
        <Box sx={styles.secondBox}>
          <Typography> {numberCard}</Typography>
          <Typography> {nameCustomer} </Typography>
        </Box>
        <Box sx={styles.thirdBox}>
          <IconButton
            data-testid={"IconCopy"}
            sx={styles.iconColor}
            onClick={() => {
              console.log(numberCard);
              handleOpen(true);
            }}
          >
            <ArrowForwardIcon />
          </IconButton>
        </Box>
        <ModalOTP
          isOpen={open}
          handleOpen={handleOpen}
          title={"Ingrese el CVV"}
          typeScreen={ScreenCard.SUCCESSFULL}
          cardId={cardId}
        />
      </Card>
    </>
  );
};
