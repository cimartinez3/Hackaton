import { createNamedStyles } from "../../shared/interfaces/create_named_styles";

export const rowCardStyles = createNamedStyles({
  firstBox: {
    marginLeft: "10px",
    paddingTop: "10px",
  },
  iconColor: {
    "&:active": {
      backgroundColor: "#F7F9F9",
    },
    "&:hover": {
      backgroundColor: "#ECF0F1",
    },
    color: "#023365",
  },
  mainCard: {
    alignItems: "center",
    borderRadius: "10px",
    columnGap: "20px",
    display: "flex",
    flexDirection: "row",
    flexWrap: "noWrap",
    height: "65%",
    justifyContent: "spaceBetween",
    marginBottom: "10px",
    marginTop: "10px",
    width: "60%",
  },
  secondBox: {
    marginLeft: "20px",
    marginRight: "40px",
    paddingTop: "6px",
  },
  thirdBox: {
    paddingTop: "6px",
  },
});
