import React from "react";
import { Box } from "@material-ui/core";
import { environment } from "../../../environments/environment";
import { PaymentMethodsEnum } from "@kushki/react-checkout/checkout/shared/constants/PaymentMethodEnum";
import { Checkout } from "@kushki/react-checkout/checkout";
import { CurrencyEnum } from "@kushki/react-checkout/checkout/shared/constants/CurrencyEnum";
import { CountryEnum } from "@kushki/react-checkout/checkout/shared/constants/CountryEnum";
import { PaymentTypeEnum } from "@kushki/react-checkout/checkout/shared/constants/PaymentTypeEnum";

const Cajita: React.FC = () => {
  return (
    <Box>
      <Checkout
        merchantId={"1f563a0b10a74d0fbcce47b0360cd614"}
        isTestEnvironment={environment.envName !== "primary"}
        email={"diego.beltran@kushkipagos.com"}
        paymentMethods={[PaymentMethodsEnum.CARD]}
        amount={{
          amount: {
            currency: CurrencyEnum.USD,
            ice: 0,
            iva: 0,
            subtotalIva: 0,
            subtotalIva0: 0,
          },
          currency: CurrencyEnum.USD,
          subTotal: 0,
          taxes: 0,
          total: 0,
        }}
        country={CountryEnum.PE}
        onCheckoutTokenChange={() => console.log("handleCharge")}
        paymentType={PaymentTypeEnum.UNIQUE}
        // @ts-ignore
        currency={CurrencyEnum.USD}
        kushkiUrl={environment.kushkiUrl}
        termsAndConditions={""}
        language={""}
        redirectUrl={""}
        redirectUrlParams={{ email: "" }}
        redirects={{ VERIFICATION_FAILED: "" }}
      />
    </Box>
  );
};

export default Cajita;
