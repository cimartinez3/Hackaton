import {
  Box,
  Card,
  CardContent,
  Divider,
  Grid,
  IconButton,
  makeStyles,
  Typography,
} from "@material-ui/core";
import React, { useEffect } from "react";
import { Theme } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import { IAppState } from "../../../store/reducer";
import { ArrowForward } from "@material-ui/icons";
import KushkiLogo from "../../../assets/logos/kushki_logo.svg";
import CreditCard from "../../../assets/logos/credit-card.svg";
import { Loading } from "../../Loading/Loading";
import { ModalOTP } from "../../Modal/Modal";
import { getOTP, setIsOTP } from "../../../store/actionCreators";
import { ScreenCard } from "../../../shared/interfaces/CardI.interface";

const useStyles = makeStyles((theme: Theme) => ({
  contentCard: {
    marginBottom: "9px",
    marginTop: "0px",
    paddingLeft: "8px",
    paddingRight: "8px",
    paddingTop: "8px",
  },
  descriptionText: {
    fontSize: "14px",
    fontWeight: 300,
    lineHeight: "140%",
  },
  detailCard: {
    borderRadius: "10px",
    boxShadow:
      "0px 15px 35px rgba(60, 66, 87, 0.12), 0px 5px 15px rgba(0, 0, 0, 0.12)",
    margin: "auto",
    maxHeight: "700px",
    padding: "16px",
  },
  productImage: {
    borderRadius: "10px",
    height: "100%",
    maxHeight: "200px",
    maxWidth: "100%",
    objectFit: "contain",
    width: "100%",
  },
  productLogoImage: {
    height: 47,
    marginLeft: 10,
    objectFit: "contain",
  },
  productNameText: {
    textTransform: "uppercase",
  },
  promotionalText: ({
    primaryColor,
  }: {
    primaryColor: string | undefined;
  }) => ({
    color: primaryColor
      ? theme.palette.text.primary
      : theme.palette.primary.dark,
    fontSize: "14px",
    fontStyle: "normal",
    fontWeight: 500,
    lineHeight: "140%",
  }),
  titleOtherPayment: {
    fontWeight: 1000,
  },
  totalText: ({ primaryColor }: { primaryColor: string | undefined }) => ({
    color: primaryColor
      ? theme.palette.text.primary
      : theme.palette.primary.dark,
    fontSize: "20px",
    fontWeight: "bold",
  }),
}));

const Detail: React.FC = () => {
  const colors = useSelector(
    (state: IAppState) => state.merchantCustomizationInfo!.colors || {}
  );
  const { primary: primaryColor } = colors;
  const classes = useStyles({ primaryColor });

  const [open, setOpen] = React.useState(false);

  const handleOpen = (open: boolean) => {
    setOpen(open);
  };

  const dispatch = useDispatch();

  const handleGetOTP = () => {
    dispatch(getOTP());
  };

  return (
    <Grid item xs={12} md={12} lg={12}>
      <Card className={classes.detailCard}>
        <CardContent className={classes.contentCard}>
          <Grid container>
            <Grid item xs={12} md={12} lg={12}>
              <Box mt={1}>
                <Grid item xs={4} md={4} lg={4}>
                  <Typography variant="h5" className={classes.productNameText}>
                    Descripción
                  </Typography>
                </Grid>
              </Box>
            </Grid>
            <Grid container item xs={12} md={12} lg={12}>
              <Grid item xs={6} md={6} lg={6}>
                <Typography variant="subtitle1" className={classes.totalText}>
                  Total
                </Typography>
              </Grid>
              <Grid item xs={6} md={6} lg={6}>
                <Typography
                  variant="subtitle1"
                  align={"right"}
                  className={classes.totalText}
                >
                  10.00 USD
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          <Box mb={2} />
          <Grid container>
            <Grid item xs={12} md={12} lg={12}>
              <Card>
                <CardContent>
                  <Grid container>
                    <Grid item xs={3} md={3} lg={3}>
                      <img
                        src={KushkiLogo}
                        alt={"product-logo"}
                        className={classes.productLogoImage}
                      />
                    </Grid>
                    <Grid item xs={6} md={6} lg={6}>
                      <Typography
                        variant={"h6"}
                        className={classes.titleOtherPayment}
                      >
                        Paga fácil y rápido
                      </Typography>
                      <Typography variant={"h6"}>
                        con tus tarjetas guardadas.
                      </Typography>
                    </Grid>
                    <Grid item xs={3} md={3} lg={3}>
                      <IconButton
                        onClick={() => {
                          handleGetOTP();
                          setOpen(true);
                        }}
                      >
                        <ArrowForward />
                      </IconButton>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12}>
              <Box mb={3} mt={3}>
                <Divider />
              </Box>
            </Grid>
            <Grid item xs={12} md={12} lg={12}>
              <Card>
                <CardContent>
                  <Grid container onClick={() => console.log("Hola")}>
                    <Grid item xs={3} md={3} lg={3}>
                      <img
                        src={CreditCard}
                        alt={"product-logo"}
                        className={classes.productLogoImage}
                      />
                    </Grid>
                    <Grid item xs={6} md={6} lg={6}>
                      <Typography
                        variant={"h6"}
                        className={classes.titleOtherPayment}
                      >
                        Tarjeta de Crédito/Debito/Prepago
                      </Typography>
                    </Grid>
                    <Grid item xs={3} md={3} lg={3}>
                      <IconButton
                        onClick={() => {
                          console.log("entramdo");
                          dispatch(setIsOTP(ScreenCard.CAJITA));
                        }}
                      >
                        <ArrowForward />
                      </IconButton>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
      <ModalOTP
        isOpen={open}
        handleOpen={handleOpen}
        title={"Ingrese el codigo OTP"}
        typeScreen={ScreenCard.CARDS}
      />
    </Grid>
  );
};

export default Detail;
