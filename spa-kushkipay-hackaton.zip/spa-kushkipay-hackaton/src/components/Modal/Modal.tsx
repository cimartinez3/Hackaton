import { loadingStyles as styles } from "../Loading/Loading.styles";
import { Box, CircularProgress, Typography } from "@mui/material";
import React, { useEffect } from "react";
import { Button, Modal, ModalDialog, Textarea } from "@mui/joy";
import { useDispatch } from "react-redux";
import { getListCards, sentToken, setIsOTP } from "../../store/actionCreators";
import { ScreenCard } from "../../shared/interfaces/CardI.interface";

export const ModalOTP: React.FC<{
  isOpen: boolean;
  handleOpen: (state: boolean) => void;
  title: string;
  typeScreen: string;
  cardId?: string;
}> = (props: {
  isOpen: boolean;
  handleOpen: (state: boolean) => void;
  title: string;
  typeScreen: string;
  cardId?: string;
}) => {
  // const { updateModal, stateModal } = useLoadingState(props.isOpen);
  const dispatch = useDispatch();

  const handleContinue = () => {
    if (props.typeScreen === ScreenCard.SUCCESSFULL)
      dispatch(sentToken(props.cardId!));
    dispatch(getListCards());
  };

  return (
    <>
      <Modal open={props.isOpen} onClose={() => props.handleOpen(false)}>
        <ModalDialog
          aria-labelledby="nested-modal-title"
          aria-describedby="nested-modal-description"
        >
          <Typography id="nested-modal-title" component="h2">
            {props.title}
          </Typography>
          <Box sx={{ height: "45px", width: "90px" }}></Box>
          <Textarea
            sx={{ backgroundColor: "#1E65AE" }}
            name="Solid"
            variant="solid"
          />

          <Box sx={{ height: "45px", width: "90px" }}></Box>

          <Box
            sx={{
              mt: 1,
              display: "flex",
              gap: 1,
              flexDirection: { xs: "column", sm: "row-reverse" },
            }}
          >
            <Button
              sx={{ backgroundColor: "#1E65AE" }}
              variant="solid"
              color="neutral"
              onClick={() => {
                props.handleOpen(false);
                handleContinue();
                dispatch(setIsOTP(props.typeScreen));
              }}
            >
              Continuar
            </Button>
            <Button
              variant="outlined"
              color="neutral"
              onClick={() => {
                props.handleOpen(false);
              }}
            >
              Cancelar
            </Button>
          </Box>
        </ModalDialog>
      </Modal>
    </>
  );
};
