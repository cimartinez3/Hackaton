import {
  CardCustomers,
  EntityNameCard,
} from "../../shared/interfaces/CardI.interface";
import { RowCardOwner } from "../RowCardOwner/RowCardOwner";
import { Box, CircularProgress } from "@mui/material";
import React, { useEffect, useState } from "react";
import { cardListStyles as styles } from "./ListCard.styles";
import { customerCard, IAppState } from "../../store/reducer";
import { useSelector } from "react-redux";

export const ListCards = () => {
  const { customerCards } = useSelector((state: IAppState) => state);

  const [listCards, setListCards] = useState<customerCard[]>([]);

  useEffect(() => {
    if (customerCards) setListCards(customerCards);
  }, [customerCards]);

  console.log(customerCards);

  return (
    <>
      <Box sx={styles.box}>
        {listCards &&
          listCards.map((data) => {
            return (
              <RowCardOwner
                key={data.id}
                type={
                  data.number!.charAt(0) === "4"
                    ? EntityNameCard.VISA
                    : EntityNameCard.MASTERCARD
                }
                numberCard={data.number!}
                nameCustomer={data.name!}
                cardId={data.id!}
              />
            );
          })}
      </Box>
    </>
  );
};
