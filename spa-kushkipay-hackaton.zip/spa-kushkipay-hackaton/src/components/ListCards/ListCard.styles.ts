import { createNamedStyles } from "../../shared/interfaces/create_named_styles";

export const cardListStyles = createNamedStyles({
  box: {
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: "10px",
    boxShadow:
      "0px 15px 35px rgba(60, 66, 87, 0.12), 0px 5px 15px rgba(0, 0, 0, 0.12)",
    display: "flex",
    // justifyContent: "center",
    flexDirection: "column",
    flexWrap: "nowrap",
    paddingBottom: "20px",
    paddingTop: "20px",
    width: "100%",
  },
});
