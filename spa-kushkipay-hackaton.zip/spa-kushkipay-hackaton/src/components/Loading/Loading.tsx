import { loadingStyles as styles } from "./Loading.styles";
import { Box, CircularProgress } from "@mui/material";
import React from "react";

export const Loading = () => {
  return (
    <>
      <Box sx={styles.boxLoading}>
        <CircularProgress />
      </Box>
    </>
  );
};
