import { createNamedStyles } from "../../shared/interfaces/create_named_styles";
import { Theme } from "@material-ui/core/styles";
import theme from "../../theme";
export const loadingStyles = createNamedStyles({
  boxLoading: {
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: "10px",
    boxShadow:
      "0px 15px 35px rgba(60, 66, 87, 0.12), 0px 5px 15px rgba(0, 0, 0, 0.12)",
    display: "flex",
    // justifyContent: "center",
    flexDirection: "column",
    flexWrap: "nowrap",
    paddingBottom: "20px",
    paddingTop: "20px",
    width: "100%",
    height: "100%",
    justifyContent: "center",
  },

  totalText: {
    fontSize: "20px",
    fontWeight: "bold",
  },
});
