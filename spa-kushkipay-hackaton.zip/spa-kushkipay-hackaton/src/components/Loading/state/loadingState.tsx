import React, { useEffect } from "react";

export const useLoadingState = (
  isOpen: boolean
): {
  updateModal: (data: boolean) => void;
  stateModal: boolean;
} => {
  const [open, setOpen] = React.useState(isOpen);

  const updateModal = (state: boolean) => {
    console.log("entre");
    setOpen(state);
  };

  useEffect(() => {
    updateModal(isOpen);
  }, [isOpen]);

  return {
    stateModal: open,
    updateModal,
  };
};
