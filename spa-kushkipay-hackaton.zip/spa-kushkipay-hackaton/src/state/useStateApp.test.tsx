import { configure, shallow, ShallowWrapper } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import { Container } from "@material-ui/core";
import { useStateApp } from "./useStateApp";
import React from "react";

configure({ adapter: new Adapter() });

describe(" Use State App", () => {
  let wrapper: ShallowWrapper;

  beforeEach(() => {
    const Component = () => {
      const useStateComponent = useStateApp();

      // @ts-ignore
      return <Container {...useStateComponent} />;
    };

    wrapper = shallow(<Component />);
  });

  it("should test screen state", () => {
    expect(wrapper.find(Container).props()).toHaveProperty("isMobile", false);
  });
});
