import { configure, shallow, ShallowWrapper } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import React from "react";
import * as errorState from "./useErrorState/useErrorState";
import ErrorIndex from "./ErrorIndex";
import { IUserErrorState } from "./useErrorState/useErrorState";
import notFoundLogo from "../../assets/notFound/notFound.svg";
import { RouteError } from "../../shared/infrastructure/RouteEnum";
import VerificationError from "../../components/ErrorIndex/VerificationError/VerificationError";
import TransactionError from "../../components/ErrorIndex/TransactionError/TransactionError";
import GenericError from "../../components/ErrorIndex/GenericError/GenericError";
import * as AllUseApp from "../../state/useStateApp";

configure({ adapter: new Adapter() });

describe("ErrorIndex Component test - ", () => {
  let wrapper: ShallowWrapper;
  let useStateSpy: jest.SpyInstance;

  const mockState = (value: IUserErrorState) => {
    useStateSpy.mockReturnValue(value);
  };

  beforeEach(() => {
    useStateSpy = jest.spyOn(errorState, "useErrorState");
    jest.spyOn(AllUseApp, "useStateApp").mockReturnValue({ isMobile: false });
  });

  afterEach(() => {
    wrapper.unmount();
    useStateSpy.mockClear();
  });

  it("must exists, when component is mounted and errorKey is transaction", () => {
    mockState({
      descriptionSecondary: "",
      errorKey: RouteError["transaction"],
      handler: jest.fn(),
      labels: {
        description: "something bad",
        icon: notFoundLogo,
        title: "error",
      },
    });
    wrapper = shallow(<ErrorIndex />);
    expect(wrapper.exists()).toBeTruthy();

    expect(wrapper.children().find(TransactionError).length).toEqual(1);
  });

  it("must exists, when component is mounted and errorKey is verification", () => {
    mockState({
      descriptionSecondary: "",
      errorKey: RouteError.verification,
      handler: jest.fn(),
      labels: {
        description: "something bad",
        icon: notFoundLogo,
        title: "error",
      },
    });
    wrapper = shallow(<ErrorIndex />);
    expect(wrapper.exists()).toBeTruthy();

    expect(wrapper.children().find(VerificationError).length).toEqual(1);
  });

  it("must exists, when component is mounted and errorKey is diferent to verification and transaction", () => {
    mockState({
      descriptionSecondary: "",
      errorKey: RouteError["wrong-link"],
      handler: jest.fn(),
      labels: {
        description: "something bad",
        icon: notFoundLogo,
        title: "error",
      },
    });
    wrapper = shallow(<ErrorIndex />);
    expect(wrapper.exists()).toBeTruthy();

    expect(wrapper.children().find(GenericError).length).toEqual(1);
  });

  it("must exists, when component is mounted and isMobile is true", () => {
    mockState({
      descriptionSecondary: "",
      errorKey: RouteError["wrong-link"],
      handler: jest.fn(),
      labels: {
        description: "something bad",
        icon: notFoundLogo,
        title: "error",
      },
    });
    jest.spyOn(AllUseApp, "useStateApp").mockReturnValue({ isMobile: true });
    wrapper = shallow(<ErrorIndex />);
    expect(wrapper.exists()).toBeTruthy();

    expect(wrapper.children().find(GenericError).length).toEqual(1);
  });
});
