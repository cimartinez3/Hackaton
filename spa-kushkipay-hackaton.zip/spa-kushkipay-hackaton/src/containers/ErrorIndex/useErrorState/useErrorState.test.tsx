import { configure, mount, ReactWrapper } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import React from "react";
import * as reactRouter from "react-router-dom";
import { useErrorState } from "./useErrorState";
import * as ReactRedux from "react-redux";
import { INITIAL_STATE } from "../../../store/reducer";

configure({ adapter: new Adapter() });

jest.mock("react-redux");
jest.mock("react-router-dom", () => ({
  useHistory: jest.fn(),
  useParams: jest.fn(),
}));

describe("useErrorState hook test - ", () => {
  let wrapper: ReactWrapper;
  let useParamsSpy: jest.SpyInstance;
  let useHistorySpy: jest.SpyInstance;
  let tryAgain: jest.Mock;

  const TestComponent: React.FC = () => {
    const props = useErrorState();

    //@ts-ignore
    return <div {...props} />;
  };

  const mockRouter = () => {
    useParamsSpy.mockImplementation(() => ({
      errorType: "default",
    }));
    useHistorySpy.mockReturnValue({
      push: tryAgain,
    });
  };

  beforeAll(() => {
    useParamsSpy = jest.spyOn(reactRouter, "useParams");
    useHistorySpy = jest.spyOn(reactRouter, "useHistory");
    jest.spyOn(ReactRedux, "useSelector").mockImplementation((state) =>
      state({
        ...INITIAL_STATE,
        amount: {
          currency: "USD",
          total: 0,
        },
        smartlink: {
          id: 1111,
        },
      })
    );
  });

  beforeEach(() => {
    tryAgain = jest.fn();
    mockRouter();
  });

  afterEach(() => {
    useParamsSpy.mockClear();
    useHistorySpy.mockClear();
  });

  it("must exists, when component is mounted", () => {
    wrapper = mount(<TestComponent />);
    expect(wrapper.exists()).toBeTruthy();
  });

  it("must call history.push, when return handler is called", () => {
    wrapper = mount(<TestComponent />);
    wrapper.childAt(0).props().handler();

    expect(tryAgain).toHaveBeenCalledTimes(1);
  });
});
