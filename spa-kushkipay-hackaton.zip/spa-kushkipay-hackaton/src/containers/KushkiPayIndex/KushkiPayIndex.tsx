import React from "react";
import { Box, CircularProgress } from "@material-ui/core";
import { useKushkiPayIndex } from "./useKushkiPayIndex";

const KushkiPayIndex: React.FC = () => {
  useKushkiPayIndex();

  return (
    <Box
      display={"flex"}
      width={"100%"}
      height={"100%"}
      position={"absolute"}
      alignItems={"center"}
      justifyContent={"center"}
    >
      <CircularProgress />
    </Box>
  );
};

export default KushkiPayIndex;
