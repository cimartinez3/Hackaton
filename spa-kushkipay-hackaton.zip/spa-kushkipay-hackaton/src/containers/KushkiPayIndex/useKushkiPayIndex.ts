import { useHistory } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { IAppState } from "../../store/reducer";
import { Routes } from "../../shared/infrastructure/RoutesEnum";
import { RouteEnum } from "../../shared/infrastructure/RouteEnum";
import { getMerchantOrder } from "../../store/actionCreators";

const useKushkiPayIndex = () => {
  const history = useHistory();
  const dispatch = useDispatch();

  const { customerEmail } = useSelector((state: IAppState) => state);

  const getCustomerEmail = () => {
    dispatch(getMerchantOrder());
  };

  useEffect(() => {
    getCustomerEmail();
  }, []);

  useEffect(() => {
    if (customerEmail !== "") history.push(RouteEnum.KUSHKI_PAY_CHECKOUT);
  }, [customerEmail]);
};

export { useKushkiPayIndex };
