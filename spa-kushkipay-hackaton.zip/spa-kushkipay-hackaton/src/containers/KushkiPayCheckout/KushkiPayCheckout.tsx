import React from "react";
import { Container, Grid, makeStyles, Theme } from "@material-ui/core";
import Detail from "../../components/KushkiPay/Detail/Detail";
import TopHeader from "../../components/commons/TopHeader/TopHeader";
import { ListCards } from "../../components/ListCards/ListCards";
import { useSelector } from "react-redux";
import { IAppState } from "../../store/reducer";
import Cajita from "../../components/KushkiPay/Cajita/Cajita";
import { ScreenCard } from "../../shared/interfaces/CardI.interface";
import { Box } from "@mui/material";
import { Successfull } from "../../components/Loading/Successfull";

const useStyles = makeStyles((theme: Theme) => ({
  boxPayments: {
    marginLeft: 20,
  },
  cardActionDesktop: {
    marginLeft: "auto",
    width: "50%",
  },
  cardActionMobile: {
    width: "100%",
  },
  container: {
    paddingBottom: 60,
  },
  previewBannerContainer: {
    bottom: "50px",
    position: "sticky",
    width: "100%",
    [theme.breakpoints.down("xs")]: {
      bottom: "50px",
    },
  },
}));

const KushkiPayCheckout: React.FC = () => {
  const classes = useStyles();

  const { isOtp, customerEmail } = useSelector((state: IAppState) => state);

  console.log(customerEmail);

  return (
    <Container maxWidth={"lg"} className={classes.container}>
      <Grid container spacing={1}>
        <Grid item xs={12}>
          <TopHeader />
        </Grid>
        <Grid container spacing={1}>
          <Grid item xs={12} sm={5}>
            <Detail />
          </Grid>
          <Grid item container direction="column" xs={12} sm={7} lg={7}>
            {/*<ListCards />*/}
            {isOtp === ScreenCard.NONE ? (
              <Box />
            ) : isOtp === ScreenCard.CARDS ? (
              <ListCards />
            ) : isOtp === ScreenCard.CAJITA ? (
              <Cajita />
            ) : (
              <Successfull />
            )}
          </Grid>
        </Grid>
      </Grid>
    </Container>
  );
};

export default KushkiPayCheckout;
