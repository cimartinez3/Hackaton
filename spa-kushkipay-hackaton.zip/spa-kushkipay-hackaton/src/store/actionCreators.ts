import { customerCard, IAppState, INITIAL_STATE } from "./reducer";
import { ActionTypes } from "./actionTypes";
import { ThunkAction, ThunkDispatch } from "redux-thunk";
import axios, { AxiosResponse } from "axios";

import {

  getSessionStorageInfo,
} from "../shared/utils/utils";

export type IAppAction = { type: string } & Partial<IAppState>;

export const setIsOTP = (payload: string): IAppAction => {
  return {
    isOtp: payload,
    type: ActionTypes.SET_IS_OTP,
  };
};

export const setCustomerEmail = (payload: string): IAppAction => {
  return {
    type: ActionTypes.SET_CUSTOMER_EMAIL,
    customerEmail: payload,
  };
};

export const setCustomerCards = (payload: customerCard[]) => {
  console.log(payload);
  return {
    type: ActionTypes.SET_CUSTOMER_CARDS,
    customerCards: payload,
  };
};

export const getMerchantOrder = (): ThunkAction<
  void,
  IAppState,
  undefined,
  IAppAction
> => {
  return async (
    dispatch: ThunkDispatch<IAppState, void, IAppAction>
  ): Promise<void> => {
    const { customerEmail, amountCheckout, currency, description } =
      getSessionStorageInfo();

    dispatch(setCustomerEmail(customerEmail!));
  };
};

export const getListCards = () => {
  return async (
    dispatch: ThunkDispatch<IAppState, void, IAppAction>,
    getState: () => IAppState
  ): Promise<void> => {
    const { customerEmail }: IAppState = getState();
    const { data } = await axios.post<customerCard[]>(
      "http://172.20.10.2:80/cards",
      {
        email: customerEmail,
      }
    );

    console.log(data);

    dispatch(setCustomerCards(data));
  };
};

export const getOTP = () => {
  return async (
    dispatch: ThunkDispatch<IAppState, void, IAppAction>,
    getState: () => IAppState
  ): Promise<void> => {
    const { customerEmail }: IAppState = getState();
    const { data } = await axios.post("http://172.20.10.2:80/email", {
      email: customerEmail,
    });

    console.log(data);
  };
};

export const sentToken = (cardId: string) => {
  return async (
    dispatch: ThunkDispatch<IAppState, void, IAppAction>
  ): Promise<void> => {
    const { data } = await axios.post("http://172.20.10.2:80/tokens", {
      cardId,
    });

    console.log(data);
  };
};
