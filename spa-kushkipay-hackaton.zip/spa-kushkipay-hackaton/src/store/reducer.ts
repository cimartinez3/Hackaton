import { MerchantSettingsResponse } from "@kushki/js/lib/types/merchant_settings_response";
import { CheckOutResume } from "../../types/checkout_resume";
import { PaymentTypeEnum } from "../shared/infrastructure/PaymentTypeEnum";
import { DynamicFormBody } from "../components/Payment/DynamicForm/DynamicForm";
import { ActionTypes } from "./actionTypes";
import { IAppAction } from "./actionCreators";
import { SmartLink } from "../../types/smart_link_V2";
import { IAmount } from "../shared/infrastructure/IAmount";
import { Customization } from "../../types/merchant_fetch";
import { SiftScienceDetails } from "../../types/sift_science_details";
import { MerchantInfo } from "../../types/merchant_info";
import { ScreenCard } from "../shared/interfaces/CardI.interface";

export interface ISelectItem {
  value: string;
  text: string;
}

export interface IDeferredOptionsFetch {
  [k: string]: {
    months: ISelectItem[];
    monthsOfGrace: ISelectItem[];
  };
}

export interface customerCard {
  id?: string;
  name?: string;
  number?: string;
}
export interface IAppState {
  isOtp?: string;
  customerEmail?: string;
  amountCheckout?: number;
  currency?: string;
  description?: string;
  customerCards?: customerCard[];
}

export const INITIAL_STATE: IAppState = {
};

export const useReducer = (
  state: IAppState = INITIAL_STATE,
  action: IAppAction
): IAppState => {
  switch (action.type) {
    case ActionTypes.SET_IS_OTP:
      return {
        ...state,
        isOtp: action.isOtp,
      };
    case ActionTypes.SET_CUSTOMER_EMAIL:
      return {
        ...state,
        customerEmail: action.customerEmail,
      };
    case ActionTypes.SET_AMOUNT_CHECKOUT:
      return {
        ...state,
        amountCheckout: action.amountCheckout,
      };
    case ActionTypes.SET_CURRENCY:
      return {
        ...state,
        currency: action.currency,
      };
    case ActionTypes.SET_DESCRIPTION:
      return {
        ...state,
        description: action.description,
      };
    case ActionTypes.SET_CUSTOMER_CARDS:
      return {
        ...state,
        customerCards: action.customerCards,
      };
    default:
      return state;
  }
};
