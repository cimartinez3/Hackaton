const fs = require("fs");
const f = "node_modules/@kushki/js/lib/infrastructure/EnvironmentEnum.js";

fs.readFile(f, "utf8", function (err, data) {
  if (err) {
    return console.log(err);
  }

  // prettier-ignore
  const result = data.replace(
    /qa/g,
    "uat"
  );

  fs.writeFile(f, result, "utf8", function (err) {
    if (err) return console.log(err);
  });
});
